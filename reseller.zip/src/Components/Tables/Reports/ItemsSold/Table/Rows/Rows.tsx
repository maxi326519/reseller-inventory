import changeDateFormat from "../../../../../../functions/changeDateFormat";
import { Item, Sale } from "../../../../../../interfaces";

import styles from "../Table.module.css";
import invoiceSvg from "../../../../../../assets/svg/invoice.svg";

interface Props {
  item: Item | undefined;
  sale: Sale;
  handleClose: () => void;
  handleRefoundSelected: (id: number) => void;
  handleDeleteSold: (id: number) => void;
  handleShowExpensesDetails: (productId: number) => void;
  handleInvoiceDetail: (invoiceId: number) => void;
}

export default function Rows({
  item,
  sale,
  handleClose,
  handleRefoundSelected,
  handleDeleteSold,
  handleShowExpensesDetails,
  handleInvoiceDetail,
}: Props) {
  function handleClick() {
    if (item) {
      handleRefoundSelected(item.id);
      handleClose();
    }
  }

  return (
    <div className={styles.rows}>
      <span>
        <b>ITEM ID: </b>
        {item?.id}
      </span>
      <span>
        <b>DATE: </b>
        {changeDateFormat(
          new Date(sale.date.toDate()).toISOString().split("T")[0]
        )}
      </span>
      <span>
        <b>COST: </b>
        {item?.cost}
      </span>
      <span>
        <b>PRICE: </b>
        {sale.price}
      </span>
      <span>
        <b>SHIPMENT: </b>
        {sale.shipment.amount !== "" ? sale.shipment.amount : 0}
      </span>
      <span>
        <b>DESCRIPTION: </b>
        {item?.description}
      </span>
      <button
        className="btn btn-primary"
        type="button"
        onClick={() => handleInvoiceDetail(item!.invoiceId)}
      >
        <img src={invoiceSvg} alt="invoice" />
      </button>
      <button className="btn btn-success" type="button" onClick={handleClick}>
        Refound
      </button>
      <button
        className="btn btn-primary"
        type="button"
        onClick={() => handleShowExpensesDetails(sale.productId)}
      >
        Expenses
      </button>
      <button
        className="btn btn-danger"
        type="button"
        onClick={() => handleDeleteSold(sale.productId)}
      >
        -
      </button>
    </div>
  );
}
